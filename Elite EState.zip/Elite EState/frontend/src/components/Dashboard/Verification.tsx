import React, { useState, useEffect } from 'react';
import { Check, X, Search, User, Mail, Calendar, PhoneCall } from 'lucide-react';

interface PendingUser {
  id: string;
  name: string;
  email: string;
  number: string;
  submittedAt: string;
  documents: string[];
  cnic_front_url: string;
  cnic_back_url: string;
}

const Verification = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [pendingUsers, setPendingUsers] = useState<PendingUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedImages, setSelectedImages] = useState<{ [key: string]: string | null }>({});

  const handleImageButtonClick = (userId: string, imageId: string) => {
    setSelectedImages((prevState) => ({
      ...prevState,
      [userId]: prevState[userId] === imageId ? null : imageId, // Toggle image visibility for this user
    }));
  };

  const loadPending = () => {
    fetch('http://localhost:5000/api/dashboard/verification', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ action: 'fetch' }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) setPendingUsers(data.data);
        setLoading(false);
      });
  };

  useEffect(() => {
    loadPending();
  }, []);

  const handleApprove = async (userId: string, userName: string) => {
    if (!window.confirm(`Approve ${userName}?`)) return;

    const res = await fetch('http://localhost:5000/api/dashboard/verification', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ action: 'approve', userId }),
    });

    const data = await res.json();

    if (data.success) {
      setPendingUsers((prev) => prev.filter((u) => u.id !== userId));
    }
  };

  const handleReject = async (userId: string, userName: string) => {
    if (!window.confirm(`Reject ${userName}?`)) return;

    const res = await fetch('http://localhost:5000/api/dashboard/verification', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ action: 'rejected', userId }),
    });

    const data = await res.json();

    if (data.success) {
      setPendingUsers((prev) => prev.filter((u) => u.id !== userId));
    }
  };

  const filteredUsers = pendingUsers.filter(
    (user) =>
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.number.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">User Verification</h2>
        <p className="text-gray-400">Review and verify pending user submissions.</p>
      </div>

      {/* Search Box */}
      <div className="bg-gray-800 rounded-xl border border-gray-700 p-4 md:p-6 mb-6">
        <div className="flex items-center gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={20} />
            <input
              type="text"
              placeholder="Search by name or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-700 rounded-lg bg-gray-700 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Loader */}
      {loading && <p className="text-white">Loading pending users...</p>}

      {/* Users List */}
      <div className="space-y-4">
        {filteredUsers.map((user) => (
          <div
            key={user.id}
            className="bg-gray-800 rounded-xl border border-gray-700 p-4 md:p-6 hover:border-gray-600 transition-all"
          >
            <div className="flex flex-col md:flex-row justify-between gap-4">
              <div className="flex gap-4 flex-1">
                <div className="bg-gray-700 rounded-full p-3 h-12 mt-5">
                  <User className="text-gray-400" size={24} />
                </div>

                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-white">{user.name}</h3>

                  <div className="flex flex-wrap gap-4 text-sm text-gray-400 mt-2">
                    <div className="flex items-center gap-1">
                      <Mail size={16} />
                      {user.email}
                    </div>

                    <div className="flex items-center gap-1">
                      <PhoneCall size={16} />
                      {user.number}
                    </div>

                    <div className="flex items-center gap-1">
                      <Calendar size={16} />
                      Submitted: {user.created_at.slice(0, 10)}
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-3">
                    <button
                      className="px-3 py-1 bg-blue-900 text-blue-300 rounded-full text-sm"
                      onClick={() => handleImageButtonClick(user.id, 'image1')}
                    >
                      Show Image 1
                    </button>
                    <button
                      className="px-3 py-1 bg-blue-900 text-blue-300 rounded-full text-sm"
                      onClick={() => handleImageButtonClick(user.id, 'image2')}
                    >
                      Show Image 2
                    </button>
                  </div>
                  <div className="mt-5">
                    {selectedImages[user.id] === 'image1' && (
                      <div className="relative">
                        <img
                          src={user.cnic_front_url}
                          alt="User Image 1"
                          className="w-full h-auto"
                        />
                        <button
                          className="absolute top-2 right-2 px-3 py-1 bg-red-600 text-white rounded-full"
                          onClick={() => handleImageButtonClick(user.id, 'image1')}
                        >
                          Close
                        </button>
                      </div>
                    )}

                    {selectedImages[user.id] === 'image2' && (
                      <div className="relative">
                        <img
                          src={user.cnic_back_url}
                          alt="User Image 2"
                          className="w-full h-auto"
                        />
                        <button
                          className="absolute top-2 right-2 px-3 py-1 bg-red-600 text-white rounded-full"
                          onClick={() => handleImageButtonClick(user.id, 'image2')}
                        >
                          Close
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Buttons */}
              <div className="flex gap-2 w-full h-10 mt-8 md:w-auto">
                <button
                  onClick={() => handleApprove(user.id, user.name)}
                  className="flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  <Check size={18} /> Approve
                </button>

                <button
                  onClick={() => handleReject(user.id, user.name)}
                  className="flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  <X size={18} /> Reject
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* No Users UI */}
      {!loading && filteredUsers.length === 0 && (
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-12 text-center">
          <div className="bg-gray-700 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
            <Check className="text-gray-500" size={32} />
          </div>
          <h3 className="text-xl text-white font-semibold">No pending verifications</h3>
          <p className="text-gray-400">All users have been reviewed.</p>
        </div>
      )}
    </div>
  );
};

export default Verification;
