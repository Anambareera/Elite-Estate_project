import React, { useEffect, useState } from 'react';
import { Users, CheckCircle, FileText } from 'lucide-react';

const DashboardHome = () => {
  const [stats, setStats] = useState({
    totalUsers: 0,
    pendingVerifications: 0,
    totalListings: 0
  });

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("http://localhost:5000/api/dashboard/stats", {
      headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
      }
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          setStats(data.data);
        }
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const uiStats = [
    {
      title: 'Total Users',
      value: stats.totalUsers,
      change: '+12.5%',
      icon: Users,
      color: 'bg-blue-500',
      lightColor: 'bg-blue-900',
      textColor: 'text-blue-400',
    },
    {
      title: 'Pending Verifications',
      value: stats.pendingVerifications,
      change: '-3.2%',
      icon: CheckCircle,
      color: 'bg-green-500',
      lightColor: 'bg-green-900',
      textColor: 'text-green-400',
    },
    {
      title: 'Total Listings',
      value: stats.totalListings,
      change: '+8.1%',
      icon: FileText,
      color: 'bg-orange-500',
      lightColor: 'bg-orange-900',
      textColor: 'text-orange-400',
    },
  ];

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">Dashboard Overview</h2>
        <p className="text-gray-400">Welcome back! Here's what's happening today.</p>
      </div>

      {loading ? (
        <p className="text-white">Loading dashboard...</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {uiStats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div
                key={index}
                className="bg-gray-800 rounded-xl shadow-sm border border-gray-700 p-6 hover:border-gray-600 transition-all"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className={`${stat.lightColor} p-3 rounded-lg`}>
                    <Icon className={stat.textColor} size={24} />
                  </div>
                </div>
                <div>
                  <p className="text-gray-400 text-sm mb-1">{stat.title}</p>
                  <p className="text-3xl font-bold text-white">{stat.value}</p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default DashboardHome;
