import React, { useEffect, useState } from 'react';
import { Search, User, Mail, Shield, Trash2 } from 'lucide-react';

interface UserData {
  id: string;
  name: string;
  email: string;
  role: string;
  verification_status: 'approved' | 'pending' | 'rejected';
  created_at: string;
}

const UserManagement = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [users, setUsers] = useState<UserData[]>([]);
  const [loading, setLoading] = useState(true);

  // Load all users initially
  const LoadUsers = async () => {
    setLoading(true);
    try {
      const res = await fetch('http://localhost:5000/api/dashboard/users', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json',
        },
      });

      const data = await res.json();
      setUsers(data); // Set the fetched users to state
    } catch (err) {
      console.error('Error loading users:', err);
    } finally {
      setLoading(false);
    }
  };

  // ✅ Load users when the component mounts
  useEffect(() => {
    LoadUsers();
  }, []);

  // Handle delete user
  const handleDelete = async (userId: string, userName: string) => {
    if (!window.confirm(`Are you sure you want to delete ${userName}? This action cannot be undone.`)) return;

    try {
      const res = await fetch('http://localhost:5000/api/dashboard/users', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'delete',
          userId: userId,
        }),
      });

      const data = await res.json();

      if (data.success) {
        // Remove the deleted user from the state (optimistic UI update)
        setUsers((prevUsers) => prevUsers.filter((user) => user.id !== userId));
        alert(`${userName} has been deleted successfully.`);
      } else {
        alert('Failed to delete user: ' + data.error);
      }
    } catch (err) {
      console.error('Error deleting user:', err);
    }
  };

  // Filter users based on search term
  const filteredUsers = users.filter(
    (user) =>
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // ✅ Loading screen
  if (loading) {
    return (
      <div className="bg-gray-800 rounded-xl shadow-sm border border-gray-700 p-10 text-center">
        <h2 className="text-xl text-white font-semibold">Loading pending users...</h2>
        <p className="text-gray-400 mt-2">Please wait.</p>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">User Management</h2>
        <p className="text-gray-400">Manage all users and their permissions.</p>
      </div>

      <div className="bg-gray-800 rounded-xl shadow-sm border border-gray-700 p-4 md:p-6 mb-6">
        <div className="flex flex-col md:flex-row gap-4 items-center">
          <div className="flex-1 w-full relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" size={20} />
            <input
              type="text"
              placeholder="Search users..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-700 rounded-lg bg-gray-700 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      <div className="bg-gray-800 rounded-xl shadow-sm border border-gray-700 overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-750 border-b border-gray-700">
            <tr>
              <th className="text-left py-4 px-4 md:px-6 text-sm font-semibold text-gray-200">User</th>
              <th className="text-left py-4 px-4 md:px-6 text-sm font-semibold text-gray-200 hidden md:table-cell">Role</th>
              <th className="text-left py-4 px-4 md:px-6 text-sm font-semibold text-gray-200">Status</th>
              <th className="text-left py-4 px-4 md:px-6 text-sm font-semibold text-gray-200 hidden lg:table-cell">Joined</th>
              <th className="text-right py-4 px-4 md:px-6 text-sm font-semibold text-gray-200">Actions</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-gray-700">
            {filteredUsers.map((user) => (
              <tr key={user.id} className="hover:bg-gray-750 transition-colors">
                <td className="py-4 px-4 md:px-6">
                  <div className="flex items-center gap-3">
                    <div className="bg-gray-700 rounded-full p-2">
                      <User className="text-gray-400" size={20} />
                    </div>
                    <div>
                      <p className="font-medium text-white">{user.name}</p>
                      <p className="text-sm text-gray-400 flex items-center gap-1">
                        <Mail size={14} />
                        {user.email}
                      </p>
                    </div>
                  </div>
                </td>

                <td className="py-4 px-4 md:px-6 hidden md:table-cell">
                  <span
                    className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium ${
                      user.role === 'admin'
                        ? 'bg-purple-900 text-purple-300'
                        : user.role === 'seller'
                        ? 'bg-blue-900 text-blue-300'
                        : 'bg-gray-700 text-gray-300'
                    }`}
                  >
                    <Shield size={14} />
                    {user.role}
                  </span>
                </td>

                <td className="py-4 px-4 md:px-6">
                  <span
                    className={`inline-flex px-3 py-1 rounded-full text-sm font-medium ${
                      user.verification_status === 'approved'
                        ? 'bg-green-900 text-green-300'
                        : user.verification_status === 'pending'
                        ? 'bg-yellow-500 text-yellow-900'
                        : 'bg-red-900 text-red-300'
                    }`}
                  >
                    {user.verification_status}
                  </span>
                </td>

                <td className="py-4 px-4 md:px-6 text-gray-400 hidden lg:table-cell">{user.created_at.slice(0, 10)}</td>

                <td className="py-4 px-4 md:px-6">
                  <div className="flex justify-end">
                    <button
                      onClick={() => handleDelete(user.id, user.name)}
                      className="p-2 text-red-400 hover:text-red-600"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {filteredUsers.length === 0 && (
        <div className="bg-gray-800 rounded-xl shadow-sm border border-gray-700 p-8 text-center mt-6">
          <div className="bg-gray-700 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
            <User className="text-gray-500" size={32} />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">No users found</h3>
          <p className="text-gray-400">Try adjusting your search.</p>
        </div>
      )}
    </div>
  );
};

export default UserManagement;
