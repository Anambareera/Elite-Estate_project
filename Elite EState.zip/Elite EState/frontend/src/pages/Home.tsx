import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, MapPin, Banknote, Home as HomeIcon, ArrowRight, Star, Users, Award } from 'lucide-react';

const Home: React.FC = () => {
  const [searchForm, setSearchForm] = useState({
    location: '',
    priceRange: '',
    propertyType: ''
  });


  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Navigate to listings with search parameters
    const params = new URLSearchParams();
    if (searchForm.location) params.append('location', searchForm.location);
    if (searchForm.priceRange) params.append('price', searchForm.priceRange);
    if (searchForm.propertyType) params.append('type', searchForm.propertyType);
    
    window.location.href = `/listings?${params.toString()}`;
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
<main>
  <section
    className="relative h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat"
    style={{
      backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url(https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=1600)'
    }}
  >
    <div className="container mx-auto px-4 text-center text-white">
      <h1 className="text-5xl md:text-6xl font-bold mb-6 opacity-0 animate-fadeIn text-shadow">
        Find Your Dream Home
      </h1>
      <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto opacity-0 animate-fadeIn text-shadow">
        Discover the perfect property that matches your lifestyle and budget with our expert guidance
      </p>
      
      {/* Search Form */}
      <div className="max-w-4xl mx-auto bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-2xl slide-up">
        <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Location Input */}
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 sm:h-6 sm:w-6 text-gray-400" />
            <input
              type="text"
              placeholder="Location"
              value={searchForm.location}
              onChange={(e) => setSearchForm({ ...searchForm, location: e.target.value })}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white text-black"
            />
          </div>

          {/* Price Range Dropdown */}
          <div className="relative">
            <Banknote className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 sm:h-6 sm:w-6 text-gray-400" />
            <select
              value={searchForm.priceRange}
              onChange={(e) => setSearchForm({ ...searchForm, priceRange: e.target.value })}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white text-black"
            >
              <option value="">Price Range</option>
              <option value="0-10000000">Under 10M</option>
              <option value="10000000-20000000">10M - 20M</option>
              <option value="20000000-30000000">20M - 30M</option>
              <option value="30000000+">30M+</option>
            </select>
          </div>

          {/* Property Type Dropdown */}
          <div className="relative">
            <HomeIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 sm:h-6 sm:w-6 text-gray-400" />
            <select
              value={searchForm.propertyType}
              onChange={(e) => setSearchForm({ ...searchForm, propertyType: e.target.value })}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white text-black"
            >
              <option value="">Property Type</option>
              <option value="house">House</option>
              <option value="apartment">Apartment</option>
              <option value="condo">Condo</option>
              <option value="townhouse">Townhouse</option>
            </select>
          </div>

          {/* Search Button */}
          <button
            type="submit"
            className="btn-primary flex items-center justify-center space-x-2"
          >
            <Search className="h-5 w-5" />
            <span>Search</span>
          </button>
        </form>
      </div>
    </div>
  </section>
</main>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50 dark:bg-gray-800">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div className="slide-up">
              <div className="bg-blue-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <HomeIcon className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">0</h3>
              <p className="text-gray-600 dark:text-gray-400">Properties Listed</p>
            </div>
            
            <div className="slide-up">
              <div className="bg-teal-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">0</h3>
              <p className="text-gray-600 dark:text-gray-400">Happy Clients</p>
            </div>
            
            <div className="slide-up">
              <div className="bg-orange-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">0</h3>
              <p className="text-gray-600 dark:text-gray-400">Years Experience</p>
            </div>
            
            <div className="slide-up">
              <div className="bg-green-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">0.0</h3>
              <p className="text-gray-600 dark:text-gray-400">Average Rating</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 gradient-bg">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto text-white">
            <h2 className="text-4xl font-bold mb-6">
              Ready to Find Your Dream Home?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Our expert agents are here to guide you through every step of your real estate journey. 
              From finding the perfect property to closing the deal, we're with you all the way.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/listings"
                className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
              >
                Browse Properties
              </Link>
              <Link
                to="/contact"
                className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors"
              >
                Contact an Agent
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;