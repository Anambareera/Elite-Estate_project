import React, { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Eye, Home, DollarSign, MapPin, Calendar, Filter, Grid, List } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

// Property Status Badge Component
const StatusBadge = ({ status }) => {
  const statusStyles = {
    active: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
    pending: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
    sold: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
    inactive: 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
  };

  return (
    <span className={`px-2 py-1 text-xs font-semibold rounded-full capitalize ${statusStyles[status] || statusStyles.active}`}>
      {status}
    </span>
  );
};

// Property Card Component for My Listings
const MyPropertyCard = ({ property, onEdit, onDelete, onView, viewMode = 'grid' }) => {
  if (viewMode === 'list') {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md border border-gray-200 dark:border-gray-700 p-6 hover:shadow-lg transition-shadow">
        <div className="flex flex-col md:flex-row md:items-center gap-4">
          <div className="md:w-48 h-32 bg-gray-200 dark:bg-gray-700 rounded-lg overflow-hidden flex-shrink-0">
            {property.image_url ? (
              <img 
                src={property.image_url} 
                alt={property.title}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Home className="h-12 w-12 text-gray-400" />
              </div>
            )}
          </div>
          
          <div className="flex-1">
            <div className="flex items-start justify-between mb-2">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{property.title}</h3>
              <StatusBadge status={property.status} />
            </div>
            
            <div className="flex items-center text-gray-600 dark:text-gray-400 text-sm mb-2">
              <MapPin className="h-4 w-4 mr-1" />
              <span>{property.location || 'Location not specified'}</span>
            </div>
            
            <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400 mb-3">
              <span>{property.bedrooms || 0} bed</span>
              <span>{property.bathrooms || 0} bath</span>
              <span className="capitalize">{property.property_type}</span>
              {property.area && <span>{property.area} sqft</span>}
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center text-blue-600 dark:text-blue-400 font-semibold">
                <DollarSign className="h-4 w-4 mr-1" />
                <span>${property.price?.toLocaleString()}</span>
              </div>
              
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onView(property)}
                  className="p-2 text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                  title="View Details"
                >
                  <Eye className="h-4 w-4" />
                </button>
                <button
                  onClick={() => onEdit(property)}
                  className="p-2 text-gray-600 dark:text-gray-400 hover:text-green-600 dark:hover:text-green-400 transition-colors"
                  title="Edit Listing"
                >
                  <Edit className="h-4 w-4" />
                </button>
                <button
                  onClick={() => onDelete(property)}
                  className="p-2 text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                  title="Delete Listing"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex items-center text-xs text-gray-500 dark:text-gray-400 mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
          <Calendar className="h-3 w-3 mr-1" />
          <span>Created: {new Date(property.created_at).toLocaleDateString()}</span>
          {property.updated_at !== property.created_at && (
            <span className="ml-4">Updated: {new Date(property.updated_at).toLocaleDateString()}</span>
          )}
        </div>
      </div>
    );
  }

  // Grid View (default)
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md border border-gray-200 dark:border-gray-700 overflow-hidden hover:shadow-lg transition-shadow">
      <div className="h-48 bg-gray-200 dark:bg-gray-700 relative">
        {property.image_url ? (
          <img 
            src={property.image_url} 
            alt={property.title}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Home className="h-16 w-16 text-gray-400" />
          </div>
        )}
        <div className="absolute top-4 right-4">
          <StatusBadge status={property.status} />
        </div>
        {property.featured && (
          <div className="absolute top-4 left-4">
            <span className="px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">
              Featured
            </span>
          </div>
        )}
      </div>
      
      <div className="p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2 line-clamp-2">
          {property.title}
        </h3>
        
        <div className="flex items-center text-gray-600 dark:text-gray-400 text-sm mb-3">
          <MapPin className="h-4 w-4 mr-1 flex-shrink-0" />
          <span className="truncate">{property.location || 'Location not specified'}</span>
        </div>
        
        <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400 mb-4">
          <span>{property.bedrooms || 0} bed</span>
          <span>{property.bathrooms || 0} bath</span>
          <span className="capitalize">{property.property_type}</span>
        </div>
        
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center text-blue-600 dark:text-blue-400 font-semibold text-lg">
            <DollarSign className="h-5 w-5 mr-1" />
            <span>${property.price?.toLocaleString()}</span>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="text-xs text-gray-500 dark:text-gray-400">
            <div className="flex items-center">
              <Calendar className="h-3 w-3 mr-1" />
              <span>{new Date(property.created_at).toLocaleDateString()}</span>
            </div>
          </div>
          
          <div className="flex items-center gap-1">
            <button
              onClick={() => onView(property)}
              className="p-2 text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors rounded-md hover:bg-gray-100 dark:hover:bg-gray-700"
              title="View Details"
            >
              <Eye className="h-4 w-4" />
            </button>
            <button
              onClick={() => onEdit(property)}
              className="p-2 text-gray-600 dark:text-gray-400 hover:text-green-600 dark:hover:text-green-400 transition-colors rounded-md hover:bg-gray-100 dark:hover:bg-gray-700"
              title="Edit Listing"
            >
              <Edit className="h-4 w-4" />
            </button>
            <button
              onClick={() => onDelete(property)}
              className="p-2 text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors rounded-md hover:bg-gray-100 dark:hover:bg-gray-700"
              title="Delete Listing"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const MyListings = () => {
  const [listings, setListings] = useState([]);
  const [verification, SetVerification] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [viewMode, setViewMode] = useState('grid');
  const [filterStatus, setFilterStatus] = useState('all');
  const [sortBy, setSortBy] = useState('created_at');
  const [sortOrder, setSortOrder] = useState('DESC');
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (userData) {
      setUser(JSON.parse(userData));
      console.log(userData)
    }

    fetchMyListings();
  }, []);

  const fetchMyListings = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      
      if (!token) {
        navigate('/auth');
        return;
      }

      const response = await fetch('http://localhost:5000/api/my-listings', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
          navigate('/auth');
          return;
        }
        throw new Error('Failed to fetch listings');
      }

      const data = await response.json();
      setListings(data.listings);
      SetVerification(data.verification_status)
    } catch (err) {
      console.error('Error fetching listings:', err);
      setError('Failed to load your listings');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (property) => {
    if (!window.confirm(`Are you sure you want to delete "${property.title}"? This action cannot be undone.`)) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:5000/api/listings/${property.id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error('Failed to delete listing');
      }

      // Remove from local state
      setListings(listings.filter(listing => listing.id !== property.id));
      
      // Show success message (you can implement a toast notification)
      alert('Listing deleted successfully');
    } catch (err) {
      console.error('Error deleting listing:', err);
      alert('Failed to delete listing. Please try again.');
    }
  };

  const handleEdit = (property) => {
    if (user?.role === 'seller' && verification !== 'approved') {
      alert('You need to be verified before you can edit listings.');
      return;
    }
    // Navigate to edit page (you'll need to create this route)
    navigate(`/edit-listing/${property.id}`, { state: { property } });
  };

  const handleView = (property) => {
    // Navigate to listing details page
    navigate(`/listing/${property.id}`);
  };

  const handleAddNew = () => {
    if (user?.role === 'seller' && verification !== 'approved') {
      alert('You need to be verified before you can create new listings.');
      return;
    }
    navigate('/add-listing');
  };

  // Filter and sort listings
  const filteredAndSortedListings = React.useMemo(() => {
    let filtered = [...listings];

    // Apply status filter
    if (filterStatus !== 'all') {
      filtered = filtered.filter(listing => listing.status === filterStatus);
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let aValue = a[sortBy];
      let bValue = b[sortBy];

      if (sortBy === 'price') {
        aValue = parseFloat(aValue) || 0;
        bValue = parseFloat(bValue) || 0;
      } else if (sortBy === 'created_at') {
        aValue = new Date(aValue);
        bValue = new Date(bValue);
      }

      if (sortOrder === 'ASC') {
        return aValue > bValue ? 1 : -1;
      } else {
        return aValue < bValue ? 1 : -1;
      }
    });

    return filtered;
  }, [listings, filterStatus, sortBy, sortOrder]);
  const isSellerPendingVerification = user?.role === 'seller' && verification === 'pending';
const isSellerRejected = user?.role === 'seller' && verification === 'rejected';
  console.log(user?.role)
  console.log(verification)
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-6">
        <div className="container mx-auto px-4">
          <div className="flex justify-center items-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-6">
        <div className="container mx-auto px-4">
          <div className="text-center py-20">
            <p className="text-red-600 dark:text-red-400 mb-4">{error}</p>
            <button 
              onClick={fetchMyListings}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Try Again
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-6">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
              My Listings
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              {filteredAndSortedListings.length} of {listings.length} listings
            </p>
          </div>
                <button
                  onClick={handleAddNew}
                  disabled={isSellerPendingVerification}
                  aria-label={isSellerPendingVerification ? "Verification is pending. You cannot add a new listing yet." : "Add a new listing"}
                  className={`flex items-center space-x-2 px-6 py-3 bg-blue-600 rounded-lg font-medium transition-colors mt-4 md:mt-0 shadow-lg transform ${
                    isSellerPendingVerification
                      ? 'bg-gray-400 text-gray-600 cursor-not-allowed'
                      : isSellerRejected
                      ? 'bg-red-500 text-black cursor-not-allowed'
                      : 'bg-blue-600 hover:bg-blue-700 text-white hover:shadow-xl hover:scale-105'
                  }`}
                >
                  
                  {isSellerPendingVerification ? "Verification Pending" : isSellerRejected ? "Verification Rejected" : <> <Plus className="h-5 w-5" /> Add New Listing</>}
                </button>

        </div>

        {/* Controls */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          {/* Filter by Status */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-800 dark:text-white"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="pending">Pending</option>
            <option value="sold">Sold</option>
            <option value="inactive">Inactive</option>
          </select>

          {/* Sort Options */}
          <select
            value={`${sortBy}-${sortOrder}`}
            onChange={(e) => {
              const [field, order] = e.target.value.split('-');
              setSortBy(field);
              setSortOrder(order);
            }}
            className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-800 dark:text-white"
          >
            <option value="created_at-DESC">Newest First</option>
            <option value="created_at-ASC">Oldest First</option>
            <option value="price-DESC">Price: High to Low</option>
            <option value="price-ASC">Price: Low to High</option>
            <option value="title-ASC">Title: A to Z</option>
            <option value="title-DESC">Title: Z to A</option>
          </select>

          {/* View Mode Toggle */}
          <div className="flex bg-white dark:bg-gray-800 rounded-lg p-1 shadow border border-gray-300 dark:border-gray-600">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded transition-colors ${
                viewMode === 'grid' 
                  ? 'bg-blue-600 text-white' 
                  : 'text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400'
              }`}
            >
              <Grid className="h-4 w-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded transition-colors ${
                viewMode === 'list' 
                  ? 'bg-blue-600 text-white' 
                  : 'text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400'
              }`}
            >
              <List className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Main Content */}
        {filteredAndSortedListings.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-gray-400 mb-6">
              <Home className="h-20 w-20 mx-auto" />
            </div>
            {listings.length === 0 ? (
              <>
                <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
                  No listings yet
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-8 max-w-md mx-auto">
                {isSellerPendingVerification 
                  ? "Your verification is pending. Please wait for approval before you can start creating listings."
                  : isSellerRejected
                  ? "Your verification was rejected. Please create a new account and complete the verification process again."
                  : "Start building your property portfolio by creating your first listing. It's easy and only takes a few minutes!"
                }

                </p>
                <button
                  onClick={handleAddNew}
                  disabled={isSellerPendingVerification}
                  aria-label={isSellerPendingVerification ? "Verification is pending. You cannot add a new listing yet." : "Add a new listing"}
                  className={`inline-flex items-center space-x-2 px-8 py-4 rounded-lg font-medium transition-colors shadow-lg transform ${
                    isSellerPendingVerification
                      ? 'bg-gray-400 text-gray-600 cursor-not-allowed'
                      : isSellerRejected
                      ? 'bg-red-500 text-black cursor-not-allowed'
                      : 'bg-blue-600 hover:bg-blue-700 text-white hover:shadow-xl hover:scale-105'
                  }`}
                >
                
                  {isSellerPendingVerification ? "Verification Pending" : isSellerRejected ? "Verification Rejected" : <> <Plus className="h-5 w-5" /> Add New Listing</>}
                </button>
              </>
            ) : (
              <>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  No listings match your filters
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  Try adjusting your status filter or search criteria
                </p>
                <button
                  onClick={() => {
                    setFilterStatus('all');
                    setSortBy('created_at');
                    setSortOrder('DESC');
                  }}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
                >
                  Clear Filters
                </button>
              </>
            )}
          </div>
        ) : (
          <div className={
            viewMode === 'grid' 
              ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6' 
              : 'space-y-6'
          }>
            {filteredAndSortedListings.map((property) => (
              <MyPropertyCard
                key={property.id}
                property={property}
                onEdit={handleEdit}
                onDelete={handleDelete}
                onView={handleView}
                viewMode={viewMode}
                isDisabled={isSellerPendingVerification}  
              />
            ))}
          </div>
        )}

        {/* Summary Stats */}
        {listings.length > 0 && (
          <div className="mt-12 grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow border border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Listings</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{listings.length}</p>
                </div>
                <Home className="h-8 w-8 text-blue-600" />
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow border border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Active</p>
                  <p className="text-2xl font-bold text-green-600">
                    {listings.filter(l => l.status === 'active').length}
                  </p>
                </div>
                <div className="h-8 w-8 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
                  <div className="h-4 w-4 bg-green-600 rounded-full"></div>
                </div>
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow border border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Sold</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {listings.filter(l => l.status === 'sold').length}
                  </p>
                </div>
                <div className="h-8 w-8 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
                  <DollarSign className="h-5 w-5 text-blue-600" />
                </div>
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow border border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Avg. Price</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    ${listings.length > 0 ? 
                      Math.round(listings.reduce((sum, l) => sum + (l.price || 0), 0) / listings.length).toLocaleString() : 
                      '0'}
                  </p>
                </div>
                <div className="h-8 w-8 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center">
                  <DollarSign className="h-5 w-5 text-gray-600" />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MyListings;