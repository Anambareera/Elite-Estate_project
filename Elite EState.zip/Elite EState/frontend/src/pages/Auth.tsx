import React, { useState, useEffect } from "react";
import { Mail, Lock, User, Phone, Send, Eye, EyeOff, Upload, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { FileUploaderMinimal, OutputFileEntry } from '@uploadcare/react-uploader';
import '@uploadcare/react-uploader/core.css';

const Auth: React.FC = () => {
  const [isSignIn, setIsSignIn] = useState(true); // toggle between Sign In & Sign Up
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    role: "buyer", // default buyer
    cnicFront: "",
    cnicBack: "",
  });

  const [uploadStatus, setUploadStatus] = useState({
    cnicFront: false,
    cnicBack: false,
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Check if user is already logged in
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      navigate("/"); // Redirect to home if already logged in
    }
  }, [navigate]);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    // Clear errors when user starts typing
    setError("");
    setSuccess("");
  };

  const resetForm = () => {
    setFormData({
      name: "",
      email: "",
      phone: "",
      password: "",
      role: "buyer",
      cnicFront: "",
      cnicBack: "",
    });
    setUploadStatus({
      cnicFront: false,
      cnicBack: false,
    });
  };

  const handleFileUpload = (fileInfo: OutputFileEntry, type: 'front' | 'back') => {
    if (fileInfo.cdnUrl) {
      setFormData(prev => ({
        ...prev,
        [type === 'front' ? 'cnicFront' : 'cnicBack']: fileInfo.cdnUrl,
      }));
      setUploadStatus(prev => ({
        ...prev,
        [type === 'front' ? 'cnicFront' : 'cnicBack']: true,
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError("");
    setSuccess("");

    // Basic validation
    if (!formData.email || !formData.password) {
      setError("Email and password are required");
      setIsSubmitting(false);
      return;
    }

    if (!isSignIn && !formData.name) {
      setError("Full name is required");
      setIsSubmitting(false);
      return;
    }

    if (formData.password.length < 6) {
      setError("Password must be at least 6 characters long");
      setIsSubmitting(false);
      return;
    }

    // CNIC validation for sellers
    if (!isSignIn && formData.role === "seller") {
      if (!formData.cnicFront || !formData.cnicBack) {
        setError("Please upload both front and back photos of your CNIC");
        setIsSubmitting(false);
        return;
      }
    }

    try {
      const endpoint = isSignIn ? "/signin" : "/signup";
      const payload = isSignIn 
        ? { email: formData.email, password: formData.password }
        : formData;

      const res = await fetch(`http://localhost:5000/api${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.message || "An error occurred");
      } else {
        if (isSignIn) {
          // Store token and user data for signin
          localStorage.setItem("token", data.token);
          localStorage.setItem("user", JSON.stringify(data.user));
          
          setSuccess("Sign in successful! Redirecting...");
          
          // Redirect after a short delay
          setTimeout(() => {
            navigate("/");
            window.location.reload(); // Refresh to update navbar
          }, 1500);
        } else {
          // For signup, show success message and switch to signin
          setSuccess("Account created successfully! Please sign in.");
          resetForm();
          setTimeout(() => {
            setIsSignIn(true);
            setSuccess("");
          }, 2000);
        }
      }
    } catch (error) {
      console.error("❌ Error:", error);
      setError("Server error. Please try again.");
    }

    setIsSubmitting(false);
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleToggleMode = () => {
    setIsSignIn(!isSignIn);
    resetForm();
    setError("");
    setSuccess("");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center px-4 py-12">
      <div className="bg-white dark:bg-gray-800 shadow-xl rounded-2xl w-full max-w-md p-8 border border-gray-200 dark:border-gray-700">
        {/* Header */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            {isSignIn ? "Welcome Back" : "Create Account"}
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            {isSignIn 
              ? "Sign in to your EliteEState account" 
              : "Join EliteEState to find your perfect property"
            }
          </p>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mb-4 p-3 bg-red-100 dark:bg-red-900/20 border border-red-300 dark:border-red-700 rounded-lg">
            <p className="text-red-700 dark:text-red-400 text-sm">{error}</p>
          </div>
        )}

        {/* Success Message */}
        {success && (
          <div className="mb-4 p-3 bg-green-100 dark:bg-green-900/20 border border-green-300 dark:border-green-700 rounded-lg">
            <p className="text-green-700 dark:text-green-400 text-sm">{success}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* SIGN UP: Name */}
          {!isSignIn && (
            <div>
              <label
                htmlFor="name"
                className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
              >
                Full Name *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full pl-10 pr-3 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:text-white transition-colors"
                  placeholder="Enter your full name"
                  required={!isSignIn}
                />
              </div>
            </div>
          )}

          {/* Email */}
          <div>
            <label
              htmlFor="email"
              className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
            >
              Email Address *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Mail className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full pl-10 pr-3 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:text-white transition-colors"
                placeholder="Enter your email"
                required
              />
            </div>
          </div>

          {/* SIGN UP: Phone */}
          {!isSignIn && (
            <div>
              <label
                htmlFor="phone"
                className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
              >
                Phone Number *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Phone className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full pl-10 pr-3 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:text-white transition-colors"
                  placeholder="Enter your phone number"
                  required
                />
              </div>
            </div>
          )}

          {/* Password */}
          <div>
            <label
              htmlFor="password"
              className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
            >
              Password *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Lock className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type={showPassword ? "text" : "password"}
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                className="w-full pl-10 pr-12 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:text-white transition-colors"
                placeholder={isSignIn ? "Enter your password" : "Create a password (min 6 characters)"}
                required
              />
              <button
                type="button"
                onClick={togglePasswordVisibility}
                className="absolute inset-y-0 right-0 pr-3 flex items-center"
              >
                {showPassword ? (
                  <EyeOff className="h-5 w-5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300" />
                ) : (
                  <Eye className="h-5 w-5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300" />
                )}
              </button>
            </div>
          </div>

          {/* SIGN UP: Role Selection */}
          {!isSignIn && (
            <div>
              <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                I am a *
              </p>
              <div className="grid grid-cols-2 gap-3">
                <label className="flex items-center space-x-3 p-3 border border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                  <input
                    type="radio"
                    name="role"
                    value="buyer"
                    checked={formData.role === "buyer"}
                    onChange={handleChange}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-gray-700 dark:text-gray-300 font-medium">
                    Buyer
                  </span>
                </label>
                <label className="flex items-center space-x-3 p-3 border border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                  <input
                    type="radio"
                    name="role"
                    value="seller"
                    checked={formData.role === "seller"}
                    onChange={handleChange}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-gray-700 dark:text-gray-300 font-medium">
                    Seller
                  </span>
                </label>
              </div>
            </div>
          )}

          {/* CNIC Upload Section - Only for Sellers */}
          {!isSignIn && formData.role === "seller" && (
            <div className="space-y-4">
              <div className="border-t border-gray-200 dark:border-gray-600 pt-4">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4 flex items-center">
                  <Upload className="h-5 w-5 mr-2" />
                  CNIC Verification Required
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                  As a seller, please upload clear photos of both sides of your CNIC for verification.
                </p>

                {/* CNIC Front Upload */}
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    CNIC Front Side *
                    {uploadStatus.cnicFront && (
                      <CheckCircle className="inline h-4 w-4 text-green-500 ml-2" />
                    )}
                  </label>
                  <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 hover:border-blue-400 transition-colors">
                    <FileUploaderMinimal
                      multiple={false}
                      sourceList="local, facebook, gdrive"
                      filesViewMode="grid"
                      classNameUploader="uc-dark uc-orange"
                      pubkey="c489b4f8395b270e4e26"
                      onFileUploadSuccess={(fileInfo: OutputFileEntry) => handleFileUpload(fileInfo, 'front')}
                    />
                    {uploadStatus.cnicFront && (
                      <p className="text-sm text-green-600 dark:text-green-400 mt-2">
                        ✓ CNIC front uploaded successfully
                      </p>
                    )}
                  </div>
                </div>

                {/* CNIC Back Upload */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    CNIC Back Side *
                    {uploadStatus.cnicBack && (
                      <CheckCircle className="inline h-4 w-4 text-green-500 ml-2" />
                    )}
                  </label>
                  <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 hover:border-blue-400 transition-colors">
                    <FileUploaderMinimal
                      multiple={false}
                      sourceList="local, facebook, gdrive"
                      filesViewMode="grid"
                      classNameUploader="uc-dark uc-orange"
                      pubkey="c489b4f8395b270e4e26"
                      onFileUploadSuccess={(fileInfo: OutputFileEntry) => handleFileUpload(fileInfo, 'back')}
                    />
                    {uploadStatus.cnicBack && (
                      <p className="text-sm text-green-600 dark:text-green-400 mt-2">
                        ✓ CNIC back uploaded successfully
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className={`w-full flex items-center justify-center space-x-2 px-6 py-3 rounded-lg font-medium transition-all duration-200 ${
              isSubmitting
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-blue-600 hover:bg-blue-700 hover:shadow-lg text-white transform hover:scale-[1.02]"
            }`}
          >
            {isSubmitting ? (
              <>
                <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></div>
                <span>{isSignIn ? "Signing In..." : "Creating Account..."}</span>
              </>
            ) : (
              <>
                <Send className="h-5 w-5" />
                <span>{isSignIn ? "Sign In" : "Create Account"}</span>
              </>
            )}
          </button>
        </form>

        {/* Toggle link */}
        <div className="mt-8 text-center">
          <p className="text-gray-600 dark:text-gray-400">
            {isSignIn ? "Don't have an account?" : "Already have an account?"}{" "}
            <button
              onClick={handleToggleMode}
              className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 font-medium hover:underline transition-colors"
            >
              {isSignIn ? "Sign Up" : "Sign In"}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Auth;