import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { LayoutDashboard, Users, CheckCircle, FileText, Menu, X } from 'lucide-react';
import DashboardHome from '../components/Dashboard/DashboardHome';
import Verification from '../components/Dashboard/Verification';
import UserManagement from '../components/Dashboard/UserManagement';
import ListManagement from '../components/Dashboard/ListManagement';

type Section = 'dashboard' | 'verification' | 'users' | 'listings';

const Dashboard = () => {
  const [activeSection, setActiveSection] = useState<Section>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [error, setError] = useState('');
  const navigate = useNavigate();

    // Retrieve user data from localStorage
  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (userData) {
      setUser(JSON.parse(userData));
    }
  }, []);

  // Once user state is updated, check role and fetch dashboard data
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/auth');
      return;
    }

    if (user) {
      // If user is an admin, fetch the dashboard data
      if (user.role !== 'admin') {
        navigate('/');
      } else {
        fetchDashboard(token); // Pass token to fetchDashboard
      }
    }
  }, [user, navigate]);

  // Function to fetch dashboard data
  const fetchDashboard = async (token) => {
    try {
      setLoading(true);
      const response = await fetch('http://localhost:5000/api/dashboard/stats', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
          localStorage.removeItem('token');
          localStorage.removeItem('user');
          navigate('/auth');
          return;
        }
        throw new Error('Failed to fetch listings');
      }

      const data = await response.json();
      console.log(data);
      // Handle dashboard data here if needed

    } catch (err) {
      console.error('Error fetching listings:', err);
      setError('Failed to load your listings');
    } finally {
      setLoading(false);
    }
  };

  const menuItems = [
    { id: 'dashboard' as Section, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'verification' as Section, label: 'Verification', icon: CheckCircle },
    { id: 'users' as Section, label: 'User Management', icon: Users },
    { id: 'listings' as Section, label: 'List Management', icon: FileText },
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return <DashboardHome />;
      case 'verification':
        return <Verification />;
      case 'users':
        return <UserManagement />;
      case 'listings':
        return <ListManagement />;
      default:
        return <DashboardHome />;
    }
  };
  

  const handleNavClick = (id: Section) => {
    setActiveSection(id);
    setSidebarOpen(false);
  };

    // Loading state while data is being fetched
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-6">
        <div className="container mx-auto px-4">
          <div className="flex justify-center items-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex">
      <aside className={`fixed md:relative w-64 bg-gray-800 border-r border-gray-700 min-h-screen z-50 transform transition-transform md:translate-x-0 ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <div className="p-6 border-b border-gray-700 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-white">Admin Panel</h1>
          <button
            onClick={() => setSidebarOpen(false)}
            className="md:hidden text-gray-400 hover:text-white"
          >
            <X size={24} />
          </button>
        </div>
        {/* Error Message (if any) */}
        {error && (
          <div className="text-red-500 mb-4">
            <p>{error}</p>
          </div>
        )}
        <nav className="p-4">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 mb-2 rounded-lg transition-all ${
                  activeSection === item.id
                    ? 'bg-blue-600 text-white font-medium'
                    : 'text-gray-400 hover:bg-gray-700 hover:text-gray-100'
                }`}
              >
                <Icon size={20} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </aside>

      <main className="flex-1 w-full">
        <div className="sticky top-0 bg-gray-800 border-b border-gray-700 p-4 md:hidden flex items-center gap-4">
          <button
            onClick={() => setSidebarOpen(true)}
            className="text-gray-400 hover:text-white"
          >
            <Menu size={24} />
          </button>
          <h1 className="text-xl font-bold text-white">Admin Panel</h1>
        </div>
        <div className="p-4 md:p-8">
          {renderContent()}
        </div>
      </main>

      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 md:hidden z-40"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
};

export default Dashboard;
