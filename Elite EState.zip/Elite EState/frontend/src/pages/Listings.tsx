import React, { useState, useEffect, useMemo } from 'react';
import { useLocation } from 'react-router-dom'; // 👈 import this
import { Filter, Grid, List, Map as MapIcon, SlidersHorizontal, Loader2, AlertCircle, RefreshCw, Search } from 'lucide-react';
import PropertyCard from '../components/PropertyCard';

// Define the Property type based on your backend schema
interface Property {
  id: number;
  title: string;
  description: string;
  price: number;
  property_type: string;
  bedrooms: number;
  bathrooms: number;
  area: number;
  location: string;
  address: string;
  image_url: string;
  featured: boolean;
  status: string;
  seller_name: string;
  created_at: string;
  updated_at: string;
}

interface FilterState {
  property_type: string;
  min_price: string;
  max_price: string;
  bedrooms: string;
  bathrooms: string;
  location: string;
}

const Listings: React.FC = () => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refetching, setRefetching] = useState(false);
  
  // Separate applied filters from draft filters
  const [appliedFilters, setAppliedFilters] = useState<FilterState>({
    property_type: '',
    min_price: '',
    max_price: '',
    bedrooms: '',
    bathrooms: '',
    location: ''
  });

  const [draftFilters, setDraftFilters] = useState<FilterState>({
    property_type: '',
    min_price: '',
    max_price: '',
    bedrooms: '',
    bathrooms: '',
    location: ''
  });

  const [viewMode, setViewMode] = useState<'grid' | 'list' | 'map'>('grid');
  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState('created_at');
  const [sortOrder, setSortOrder] = useState('DESC');

  const locationHook = useLocation(); // 👈 to read ?search=...
  const API_BASE_URL = 'http://localhost:5000/api';

  // Check if there are pending filter changes
  const hasFilterChanges = useMemo(() => {
    return JSON.stringify(appliedFilters) !== JSON.stringify(draftFilters);
  }, [appliedFilters, draftFilters]);

  // Fetch properties
  const fetchProperties = async (isRefetch = false) => {
    try {
      if (isRefetch) setRefetching(true);
      else setLoading(true);

      setError(null);

      const queryParams = new URLSearchParams();

      // Apply filters using appliedFilters (not draftFilters)
      if (appliedFilters.property_type) queryParams.append('property_type', appliedFilters.property_type);
      if (appliedFilters.min_price) queryParams.append('min_price', appliedFilters.min_price);
      if (appliedFilters.max_price) queryParams.append('max_price', appliedFilters.max_price);
      if (appliedFilters.bedrooms) queryParams.append('bedrooms', appliedFilters.bedrooms);
      if (appliedFilters.bathrooms) queryParams.append('bathrooms', appliedFilters.bathrooms);
      if (appliedFilters.location) queryParams.append('location', appliedFilters.location);

      // 👇 Handle search param from URL
      const params = new URLSearchParams(locationHook.search);
      const searchQuery = params.get('search');
      if (searchQuery) {
        queryParams.append('location', searchQuery); // backend already supports location filter
      }

      queryParams.append('sort', sortBy);
      queryParams.append('order', sortOrder);
      queryParams.append('limit', '50');

      const res = await fetch(`${API_BASE_URL}/listings?${queryParams}`);
      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);

      const data = await res.json();
      setProperties(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch properties');
    } finally {
      setLoading(false);
      setRefetching(false);
    }
  };

  // Apply filters function
  const applyFilters = () => {
    setAppliedFilters({ ...draftFilters });
  };

  // Run when appliedFilters, sorting OR URL search query changes
  useEffect(() => {
    fetchProperties();
  }, [appliedFilters, sortBy, sortOrder, locationHook.search]); // 👈 notice appliedFilters instead of filters

  // Handle sort change
  const handleSortChange = (value: string) => {
    switch (value) {
      case 'price-low':
        setSortBy('price');
        setSortOrder('ASC');
        break;
      case 'price-high':
        setSortBy('price');
        setSortOrder('DESC');
        break;
      case 'newest':
        setSortBy('created_at');
        setSortOrder('DESC');
        break;
      case 'oldest':
        setSortBy('created_at');
        setSortOrder('ASC');
        break;
      case 'title':
        setSortBy('title');
        setSortOrder('ASC');
        break;
      default:
        setSortBy('created_at');
        setSortOrder('DESC');
    }
  };

  // Updated Sort Dropdown with correct value mapping
  const getSortValue = () => {
    if (sortBy === 'price' && sortOrder === 'ASC') return 'price-low';
    if (sortBy === 'price' && sortOrder === 'DESC') return 'price-high';
    if (sortBy === 'created_at' && sortOrder === 'ASC') return 'oldest';
    if (sortBy === 'created_at' && sortOrder === 'DESC') return 'newest';
    if (sortBy === 'title' && sortOrder === 'ASC') return 'title';
    return 'newest'; // default
  };

  const clearFilters = () => {
    const emptyFilters = {
      property_type: '',
      min_price: '',
      max_price: '',
      bedrooms: '',
      bathrooms: '',
      location: ''
    };
    setDraftFilters(emptyFilters);
    setAppliedFilters(emptyFilters);
  };

  const LoadingState = () => (
    <div className="flex items-center justify-center py-16">
      <div className="text-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600 mx-auto mb-4" />
        <p className="text-gray-600 dark:text-gray-400">Loading properties...</p>
      </div>
    </div>
  );

  const ErrorState = () => (
    <div className="flex items-center justify-center py-16">
      <div className="text-center">
        <AlertCircle className="h-16 w-16 text-red-400 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
          Error Loading Properties
        </h3>
        <p className="text-gray-600 dark:text-gray-400 mb-4">{error}</p>
        <button
          onClick={() => fetchProperties()}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Try Again
        </button>
      </div>
    </div>
  );

  if (loading && !refetching) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-6">
        <div className="container mx-auto px-4">
          <LoadingState />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-6">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
              Property Listings
            </h1>
            <p className="text-gray-600 dark:text-gray-400 flex items-center gap-2">
              {properties.length} properties available
              {refetching && <Loader2 className="h-4 w-4 animate-spin" />}
            </p>
          </div>

          <div className="flex items-center space-x-4 mt-4 md:mt-0">
            {/* Mobile Filter Toggle */}
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="lg:hidden p-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              <SlidersHorizontal className="h-4 w-4" />
            </button>

            {/* Refresh Button */}
            <button
              onClick={() => fetchProperties(true)}
              disabled={refetching}
              className="p-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`h-4 w-4 ${refetching ? 'animate-spin' : ''}`} />
            </button>

            {/* Sort Dropdown */}
            <select
              value={getSortValue()}
              onChange={(e) => handleSortChange(e.target.value)}
              className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-800 dark:text-white"
            >
              <option value="newest">Newest First</option>
              <option value="oldest">Oldest First</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="title">Title A-Z</option>
            </select>

            {/* View Mode Toggle */}
            <div className="flex bg-white dark:bg-gray-800 rounded-lg p-1 shadow">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded ${viewMode === 'grid' ? 'bg-blue-600 text-white' : 'text-gray-600 dark:text-gray-400'}`}
              >
                <Grid className="h-4 w-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded ${viewMode === 'list' ? 'bg-blue-600 text-white' : 'text-gray-600 dark:text-gray-400'}`}
              >
                <List className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className={`lg:w-80 ${showFilters ? 'block' : 'hidden lg:block'}`}>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Filters</h3>
                <button
                  onClick={clearFilters}
                  className="text-blue-600 hover:text-blue-700 text-sm font-medium"
                >
                  Clear All
                </button>
              </div>

              <div className="space-y-6">
                {/* Property Type */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Property Type
                  </label>
                  <select
                    value={draftFilters.property_type}
                    onChange={(e) => setDraftFilters({...draftFilters, property_type: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  >
                    <option value="">All Types</option>
                    <option value="house">House</option>
                    <option value="apartment">Apartment</option>
                    <option value="Land">Land</option>
                    {/* <option value="townhouse">Townhouse</option> */}
                  </select>
                </div>

                {/* Price Range */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Price Range
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="number"
                      placeholder="Min Price"
                      value={draftFilters.min_price}
                      onChange={(e) => setDraftFilters({...draftFilters, min_price: e.target.value})}
                      className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                    />
                    <input
                      type="number"
                      placeholder="Max Price"
                      value={draftFilters.max_price}
                      onChange={(e) => setDraftFilters({...draftFilters, max_price: e.target.value})}
                      className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                    />
                  </div>
                </div>

                {/* Bedrooms */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Minimum Bedrooms
                  </label>
                  <select
                    value={draftFilters.bedrooms}
                    onChange={(e) => setDraftFilters({...draftFilters, bedrooms: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  >
                    <option value="">Any</option>
                    <option value="1">1+</option>
                    <option value="2">2+</option>
                    <option value="3">3+</option>
                    <option value="4">4+</option>
                  </select>
                </div>

                {/* Bathrooms */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Minimum Bathrooms
                  </label>
                  <select
                    value={draftFilters.bathrooms}
                    onChange={(e) => setDraftFilters({...draftFilters, bathrooms: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  >
                    <option value="">Any</option>
                    <option value="1">1+</option>
                    <option value="2">2+</option>
                    <option value="3">3+</option>
                  </select>
                </div>

                {/* Location */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Location
                  </label>
                  <input
                    type="text"
                    placeholder="Enter city or area"
                    value={draftFilters.location}
                    onChange={(e) => setDraftFilters({...draftFilters, location: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  />
                </div>

                {/* Apply Filters Button */}
                <div className="pt-4">
                  <button
                    onClick={applyFilters}
                    disabled={!hasFilterChanges}
                    className={`w-full flex items-center justify-center gap-2 px-4 py-3 rounded-lg font-medium transition-colors ${
                      hasFilterChanges
                        ? 'bg-blue-600 hover:bg-blue-700 text-white'
                        : 'bg-gray-300 dark:bg-gray-600 text-gray-500 dark:text-gray-400 cursor-not-allowed'
                    }`}
                  >
                    <Search className="h-4 w-4" />
                    Apply Filters
                  </button>
                </div>

                {/* Filter Status Indicator */}
                {hasFilterChanges && (
                  <div className="text-sm text-amber-600 dark:text-amber-400 text-center">
                    You have unsaved filter changes
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {error ? (
              <ErrorState />
            ) : viewMode === 'map' ? (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-8 text-center">
                <MapIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-400">Map view coming soon...</p>
              </div>
            ) : (
              <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' : 'space-y-6'}>
                {properties.map((property) => (
                  <PropertyCard
                    key={property.id}
                    property={{
                      id: property.id.toString(),
                      title: property.title,
                      price: property.price,
                      location: property.location,
                      bedrooms: property.bedrooms,
                      bathrooms: property.bathrooms,
                      squareFeet: property.area || 0,
                      type: property.property_type,
                      images: property.image_url ? [property.image_url] : ['https://placehold.co/400x300'],
                      featured: property.featured,
                      description: property.description || ''
                    }}
                    showFavorite
                  />
                ))}
              </div>
            )}

            {!error && !loading && properties.length === 0 && (
              <div className="text-center py-16">
                <div className="text-gray-400 mb-4">
                  <Filter className="h-16 w-16 mx-auto" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  No properties found
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  Try adjusting your search criteria to see more results
                </p>
                <button
                  onClick={clearFilters}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Clear Filters
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Listings;