import React, { useState, useEffect } from 'react';
import { ArrowLeft, MapPin, Bed, Bath, Square, Calendar, Phone, Mail, MessageCircle, Share2, Loader2, AlertCircle, X, Copy, Facebook, Twitter, Linkedin } from 'lucide-react';
import { useParams } from "react-router-dom";

// Backend property type
interface BackendProperty {
  id: number;
  title: string;
  description: string;
  price: number;
  property_type: string;
  bedrooms: number;
  bathrooms: number;
  area: number;
  location: string;
  address: string;
  image_url: string;
  featured: boolean;
  status: string;
  seller_name: string;
  seller_email: string;
  seller_phone: string;
  created_at: string;
  updated_at: string;
}

const PropertyDetails: React.FC = () => {
  // For demo purposes, using a hardcoded ID. In real app, get from useParams
  const { id } = useParams<{ id: string }>();
  const [property, setProperty] = useState<BackendProperty | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showContactForm, setShowContactForm] = useState(false);
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [submittingContact, setSubmittingContact] = useState(false);

  useEffect(() => {
    const fetchProperty = async () => {
      if (!id) return;
      
      try {
        setLoading(true);
        setError(null);
        
        const response = await fetch(`http://localhost:5000/api/listings/${id}`);

        if (!response.ok) {
          if (response.status === 404) {
            throw new Error('Property not found');
          }
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log(data)

        setProperty(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch property');
        console.error('Error fetching property:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchProperty();
  }, [id]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'PKR',
      minimumFractionDigits: 0,
    }).format(price);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const handleContactSubmit = async () => {
    setSubmittingContact(true);

    try {
      // In a real app, you'd send this to your backend
      // For now, we'll simulate the API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      console.log('Contact form submitted:', {
        ...contactForm,
        propertyId: id,
        sellerEmail: property?.seller_email
      });
      
      alert('Thank you! Your message has been sent to the seller.');
      setShowContactForm(false);
      setContactForm({ name: '', email: '', phone: '', message: '' });
    } catch (err) {
      alert('Failed to send message. Please try again.');
    } finally {
      setSubmittingContact(false);
    }
  };

  // Get current property URL for sharing
  const getCurrentUrl = () => {
    return window.location.href;
  };

  // Handle copy to clipboard
  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(getCurrentUrl());
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    } catch (err) {
      console.error('Failed to copy URL:', err);
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = getCurrentUrl();
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    }
  };

const handleFacebookShare = () => {
  const url = encodeURIComponent(getCurrentUrl());  // Get the current URL of the property page
  const hashtag = encodeURIComponent('#AmazingProperty');
  const fbSharerUrl = `https://www.facebook.com/share_channel/?type=reshare&link=${url}&app_id=87741124305&source_surface=external_reshare&display=popup&hashtag=${hashtag}&`;
  window.open(fbSharerUrl, '_blank');
};



  const handleTwitterShare = () => {
    const url = encodeURIComponent(getCurrentUrl());
    const text = encodeURIComponent(`Check out this amazing ${property?.property_type} in ${property?.location} - ${formatPrice(property?.price || 0)}`);
    window.open(`https://twitter.com/intent/tweet?url=${url}&text=${text}`, '_blank');
  
  };

  const handleLinkedInShare = () => {
    const url = encodeURIComponent(getCurrentUrl());
    window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${url}`, '_blank');
  };

  const handleEmailShare = () => {
    const subject = encodeURIComponent(`Check out this property: ${property?.title}`);
    const body = encodeURIComponent(`I found this amazing ${property?.property_type} in ${property?.location} and thought you might be interested!\n\nPrice: ${formatPrice(property?.price || 0)}\nLocation: ${property?.location}\n\nCheck it out: ${getCurrentUrl()}`);
    // window.location.href = `mailto:?subject=${subject}&body=${body}`;
    window.open(`mailto:?subject=${subject}&body=${body}`, '_blank');
  };

  // Get multiple images from image_url (assuming it might be comma-separated or just one)
  const getPropertyImages = (imageUrl: string) => {
    if (!imageUrl) return ['https://placehold.co/800x600'];
    
    // If comma-separated URLs, split them; otherwise use single URL
    const images = imageUrl.includes(',') 
      ? imageUrl.split(',').map(url => url.trim())
      : [imageUrl];
    
    return images.length > 0 ? images : ['https://placehold.co/800x600'];
  };

  // Default features based on property type and amenities
  const getDefaultFeatures = (property: BackendProperty) => {
    const features = [];
    
    if (property.bedrooms > 2) features.push('Spacious Bedrooms');
    if (property.bathrooms > 1) features.push('Multiple Bathrooms');
    if (property.area > 1500) features.push('Large Living Space');
    
    // Add some common features based on property type
    switch (property.property_type.toLowerCase()) {
      case 'house':
        features.push('Private Yard', 'Garage', 'Garden');
        break;
      case 'apartment':
        features.push('Building Amenities', 'Security', 'Elevator');
        break;
      case 'condo':
        features.push('HOA Amenities', 'Balcony', 'Modern Fixtures');
        break;
      case 'townhouse':
        features.push('Multi-level', 'Private Entrance', 'Patio');
        break;
    }
    
    features.push('Prime Location', 'Near Transportation', 'Shopping Nearby');
    
    return features;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Loading property details...</p>
        </div>
      </div>
    );
  }

  if (error || !property) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="h-16 w-16 text-red-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            {error || 'Property not found'}
          </h2>
          <button 
            onClick={() => window.history.back()}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Back to Listings
          </button>
        </div>
      </div>
    );
  }

  const propertyImages = getPropertyImages(property.image_url);
  const features = getDefaultFeatures(property);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-6">
      <div className="container mx-auto px-4">
        {/* Back Button */}
        <div className="mb-6">
          <button
            onClick={() => window.history.back()}
            className="inline-flex items-center space-x-2 text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>Back to Listings</span>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Image Gallery */}
            <div className="mb-8">
              <div className="relative mb-4">
                <img
                  src={propertyImages[currentImageIndex]}
                  alt={property.title}
                  className="w-full h-96 object-cover rounded-lg"
                />
                <div className="absolute top-4 right-4 flex space-x-2">
                  <button 
                    onClick={() => setShowShareDialog(true)}
                    className="p-2 bg-white/90 rounded-full hover:bg-white transition-colors shadow-lg"
                  >
                    <Share2 className="h-5 w-5 text-gray-600" />
                  </button>
                </div>
                {property.featured && (
                  <div className="absolute top-4 left-4 bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                    Featured
                  </div>
                )}
              </div>
              
              {propertyImages.length > 1 && (
                <div className="grid grid-cols-4 gap-2">
                  {propertyImages.slice(0, 4).map((image, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`relative h-20 rounded-lg overflow-hidden ${
                        currentImageIndex === index ? 'ring-2 ring-blue-600' : ''
                      }`}
                    >
                      <img
                        src={image}
                        alt={`${property.title} ${index + 1}`}
                        className="w-full h-full object-cover hover:scale-105 transition-transform"
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Property Info */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-8">
              <div className="flex items-center justify-between mb-4">
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                  {property.title}
                </h1>
                <span className="text-3xl font-bold text-blue-600 dark:text-blue-400">
                  {formatPrice(property.price)}
                </span>
              </div>

              <div className="flex items-center text-gray-600 dark:text-gray-400 mb-2">
                <MapPin className="h-5 w-5 mr-2" />
                <span className="text-lg">{property.location}</span>
              </div>

              {property.address && (
                <div className="text-gray-500 dark:text-gray-400 mb-6">
                  <span className="text-sm">{property.address}</span>
                </div>
              )}

              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
                <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <Bed className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-900 dark:text-white">
                    {property.bedrooms}
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Bedrooms</div>
                </div>
                
                <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <Bath className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-900 dark:text-white">
                    {property.bathrooms}
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Bathrooms</div>
                </div>
                
                <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <Square className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-900 dark:text-white">
                    {property.area ? property.area.toLocaleString() : 'N/A'}
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Sq Ft</div>
                </div>
                
                <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg capitalize">
                  <Calendar className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                  <div className="text-xl font-bold text-gray-900 dark:text-white capitalize">
                    {property.property_type}
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Type</div>
                </div>
              </div>

              <div className="mb-8">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  Description
                </h3>
                <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                  {property.description || 'No description available for this property.'}
                </p>
              </div>

              <div className="mb-8">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  Features & Amenities
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {features.map((feature, index) => (
                    <div
                      key={index}
                      className="flex items-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg"
                    >
                      <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                      <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  Property Details
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div className="flex justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded">
                    <span className="text-gray-600 dark:text-gray-400">Status:</span>
                    <span className="capitalize text-gray-900 dark:text-white">{property.status}</span>
                  </div>
                  <div className="flex justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded">
                    <span className="text-gray-600 dark:text-gray-400">Listed:</span>
                    <span className="text-gray-900 dark:text-white">{formatDate(property.created_at)}</span>
                  </div>
                  <div className="flex justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded">
                    <span className="text-gray-600 dark:text-gray-400">Updated:</span>
                    <span className="text-gray-900 dark:text-white">{formatDate(property.updated_at)}</span>
                  </div>
                  <div className="flex justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded">
                    <span className="text-gray-600 dark:text-gray-400">Property ID:</span>
                    <span className="text-gray-900 dark:text-white">#{property.id}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Location Map */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                Location
              </h3>
              <div className="h-64 bg-gray-200 dark:bg-gray-700 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">Interactive map would be shown here</p>
                  <p className="text-sm text-gray-500 dark:text-gray-500 mt-2">
                    Location: {property.location}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* Seller Contact */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-8">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                Contact Seller
              </h3>
              
              <div className="flex items-center mb-6">
                <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mr-4">
                  <span className="text-white text-xl font-bold">
                    {property.seller_name.charAt(0).toUpperCase()}
                  </span>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 dark:text-white">
                    {property.seller_name}
                  </h4>
                  <p className="text-gray-600 dark:text-gray-400">Property Owner</p>
                </div>
              </div>

              <div className="space-y-3 mb-6">
                {property.seller_phone && (
                  <a
                    href={`tel:${property.seller_phone}`}
                    className="flex items-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                  >
                    <Phone className="h-5 w-5 text-blue-600 mr-3" />
                    <span className="text-gray-700 dark:text-gray-300">{property.seller_phone}</span>
                  </a>
                )}
                
                <a
                  href={`mailto:${property.seller_email}`}
                  className="flex items-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                >
                  <Mail className="h-5 w-5 text-blue-600 mr-3" />
                  <span className="text-gray-700 dark:text-gray-300">{property.seller_email}</span>
                </a>
              </div>

              <button
                onClick={() => setShowContactForm(!showContactForm)}
                className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
              >
                <MessageCircle className="h-5 w-5" />
                <span>Send Message</span>
              </button>

              {showContactForm && (
                <div className="mt-6 space-y-4">
                  <input
                    type="text"
                    placeholder="Your Name"
                    value={contactForm.name}
                    onChange={(e) => setContactForm({...contactForm, name: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  />
                  <input
                    type="email"
                    placeholder="Your Email"
                    value={contactForm.email}
                    onChange={(e) => setContactForm({...contactForm, email: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  />
                  <input
                    type="tel"
                    placeholder="Your Phone"
                    value={contactForm.phone}
                    onChange={(e) => setContactForm({...contactForm, phone: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  />
                  <textarea
                    placeholder="Your Message"
                    rows={4}
                    value={contactForm.message}
                    onChange={(e) => setContactForm({...contactForm, message: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white resize-none"
                  ></textarea>
                  <div className="flex space-x-2">
                    <button 
                      type="button"
                      onClick={handleContactSubmit}
                      disabled={submittingContact}
                      className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center justify-center"
                    >
                      {submittingContact ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        'Send Message'
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowContactForm(false)}
                      className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Schedule Visit */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                Schedule a Visit
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Book a private tour of this property with the seller
              </p>
              <button className="w-full bg-gray-200 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors flex items-center justify-center space-x-2">
                <Calendar className="h-5 w-5" />
                <span>Schedule Tour</span>
              </button>
            </div>
          </div>
        </div>

        {/* Share Dialog */}
        {showShareDialog && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full">
              <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-600">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Share Property
                </h3>
                <button
                  onClick={() => setShowShareDialog(false)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
              
              <div className="p-6 space-y-4">
                {/* Property Info */}
                <div className="flex items-center space-x-3 mb-6">
                  <img
                    src={propertyImages[0]}
                    alt={property.title}
                    className="w-16 h-16 object-cover rounded-lg"
                  />
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-white line-clamp-1">
                      {property.title}
                    </h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {property.location} • {formatPrice(property.price)}
                    </p>
                  </div>
                </div>

                {/* Copy Link */}
                <div className="relative">
                  <input
                    type="text"
                    value={getCurrentUrl()}
                    readOnly
                    className="w-full px-4 py-3 pr-20 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-sm"
                  />
                  <button
                    onClick={handleCopyUrl}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 px-3 py-1.5 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition-colors flex items-center space-x-1"
                  >
                    <Copy className="h-4 w-4" />
                    <span>{copySuccess ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>

                {/* Social Share Buttons */}
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={handleFacebookShare}
                    className="flex items-center justify-center space-x-2 p-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Facebook className="h-5 w-5" />
                    <span>Facebook</span>
                  </button>
                  
                  <button
                    onClick={handleTwitterShare}
                    className="flex items-center justify-center space-x-2 p-3 bg-sky-500 text-white rounded-lg hover:bg-sky-600 transition-colors"
                  >
                    <Twitter className="h-5 w-5" />
                    <span>Twitter</span>
                  </button>
                  
                  <button
                    onClick={handleLinkedInShare}
                    className="flex items-center justify-center space-x-2 p-3 bg-blue-700 text-white rounded-lg hover:bg-blue-800 transition-colors"
                  >
                    <Linkedin className="h-5 w-5" />
                    <span>LinkedIn</span>
                  </button>
                  
                  <button
                    onClick={handleEmailShare}
                    className="flex items-center justify-center space-x-2 p-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
                  >
                    <Mail className="h-5 w-5" />
                    <span>Email</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PropertyDetails;