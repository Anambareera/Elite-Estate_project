export interface Property {
  id: string;
  title: string;
  description: string;
  price: number;
  location: string;
  bedrooms: number;
  bathrooms: number;
  squareFeet: number;
  type: 'house' | 'apartment' | 'condo' | 'townhouse';
  images: string[];
  features: string[];
  agent: {
    name: string;
    phone: string;
    email: string;
    image: string;
  };
  coordinates: {
    lat: number;
    lng: number;
  };
  featured: boolean;
}

export const properties: Property[] = [
  {
    id: '1',
    title: 'Modern Downtown Penthouse',
    description: 'Stunning penthouse with panoramic city views, featuring floor-to-ceiling windows, premium finishes, and a private rooftop terrace. Perfect for urban living with luxury amenities.',
    price: 1250000,
    location: 'Downtown, New York',
    bedrooms: 3,
    bathrooms: 2,
    squareFeet: 2100,
    type: 'apartment',
    images: [
      'https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/2029667/pexels-photo-2029667.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    features: ['City Views', 'Rooftop Terrace', 'Modern Kitchen', 'Parking', 'Gym Access'],
    agent: {
      name: 'Ritika',
      phone: '+1 (555) 123-4567',
      email: 'Example@gmail.com',
      image: 'https://cdn.discordapp.com/attachments/1287673374423646230/1417553021658861670/33uv0r2h.gif?ex=68cae6a1&is=68c99521&hm=4771e62a127bbb6eb125b2667bef28f74a5a54046f109d849a05993cf004abb0&'
    },
    coordinates: { lat: 40.7128, lng: -74.0060 },
    featured: true
  },
  {
    id: '2',
    title: 'Charming Suburban Family Home',
    description: 'Beautiful family home in quiet neighborhood with spacious backyard, updated kitchen, and excellent school district. Perfect for growing families.',
    price: 650000,
    location: 'Westfield, NJ',
    bedrooms: 4,
    bathrooms: 3,
    squareFeet: 2800,
    type: 'house',
    images: [
      'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1571453/pexels-photo-1571453.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    features: ['Large Backyard', 'Updated Kitchen', 'Garage', 'Fireplace', 'Near Schools'],
    agent: {
      name: 'Arisha',
      phone: '+1 (555) 987-6543',
      email: 'Example@gmail.com',
      image: 'https://cdn.discordapp.com/attachments/1287673374423646230/1417553021658861670/33uv0r2h.gif?ex=68cae6a1&is=68c99521&hm=4771e62a127bbb6eb125b2667bef28f74a5a54046f109d849a05993cf004abb0&'
    },
    coordinates: { lat: 40.6584, lng: -74.3479 },
    featured: true
  },
  {
    id: '3',
    title: 'Luxury Waterfront Condo',
    description: 'Exquisite waterfront condominium with breathtaking ocean views, private beach access, and world-class amenities. Resort-style living at its finest.',
    price: 890000,
    location: 'Miami Beach, FL',
    bedrooms: 2,
    bathrooms: 2,
    squareFeet: 1600,
    type: 'condo',
    images: [
      'https://images.pexels.com/photos/1571468/pexels-photo-1571468.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/2883049/pexels-photo-2883049.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1457847/pexels-photo-1457847.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    features: ['Ocean Views', 'Beach Access', 'Pool', 'Spa', 'Concierge'],
    agent: {
      name: 'Emily Rodriguez',
      phone: '+1 (555) 456-7890',
      email: 'emily@realestate.com',
      image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    coordinates: { lat: 25.7617, lng: -80.1918 },
    featured: true
  },
  {
    id: '4',
    title: 'Cozy Urban Townhouse',
    description: 'Charming townhouse in trendy neighborhood with exposed brick walls, hardwood floors, and private patio. Walking distance to restaurants and shops.',
    price: 475000,
    location: 'Brooklyn, NY',
    bedrooms: 2,
    bathrooms: 1,
    squareFeet: 1200,
    type: 'townhouse',
    images: [
      'https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1571457/pexels-photo-1571457.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/2747901/pexels-photo-2747901.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    features: ['Exposed Brick', 'Hardwood Floors', 'Private Patio', 'Walk Score 95', 'Historic Charm'],
    agent: {
      name: 'David Wilson',
      phone: '+1 (555) 321-9876',
      email: 'david@realestate.com',
      image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    coordinates: { lat: 40.6782, lng: -73.9442 },
    featured: false
  },
  {
    id: '5',
    title: 'Contemporary Mountain Retreat',
    description: 'Stunning contemporary home nestled in the mountains with panoramic valley views, floor-to-ceiling windows, and seamless indoor-outdoor living spaces.',
    price: 1150000,
    location: 'Aspen, CO',
    bedrooms: 3,
    bathrooms: 3,
    squareFeet: 2400,
    type: 'house',
    images: [
      'https://images.pexels.com/photos/1396132/pexels-photo-1396132.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1571471/pexels-photo-1571471.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/2089698/pexels-photo-2089698.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    features: ['Mountain Views', 'Floor-to-Ceiling Windows', 'Fireplace', 'Deck', 'Modern Design'],
    agent: {
      name: 'Jennifer Martinez',
      phone: '+1 (555) 654-3210',
      email: 'jennifer@realestate.com',
      image: 'https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    coordinates: { lat: 39.1911, lng: -106.8175 },
    featured: false
  }
];

export const teamMembers = [
  {
    id: '1',
    name: 'Arisha Junejo',
    position: 'FrontEnd Tech',
    bio: '',
    image: 'https://cdn.discordapp.com/attachments/1287673374423646230/1417553021658861670/33uv0r2h.gif?ex=68cae6a1&is=68c99521&hm=4771e62a127bbb6eb125b2667bef28f74a5a54046f109d849a05993cf004abb0&',
    phone: '+923068381212',
    email: 'Example @gmail.com'
  },
  {
    id: '2',
    name: 'Payal',
    position: 'BackEnd Tech',
    bio: '',
    image: 'https://cdn.discordapp.com/attachments/1287673374423646230/1417553021658861670/33uv0r2h.gif?ex=68cae6a1&is=68c99521&hm=4771e62a127bbb6eb125b2667bef28f74a5a54046f109d849a05993cf004abb0&',
    phone: '+923335010990',
    email: 'Example @gmail.com'
  },
  {
    id: '3',
    name: 'Anam',
    position: 'Manages the Data.',
    bio: '',
    image: 'https://cdn.discordapp.com/attachments/1287673374423646230/1417553021658861670/33uv0r2h.gif?ex=68cae6a1&is=68c99521&hm=4771e62a127bbb6eb125b2667bef28f74a5a54046f109d849a05993cf004abb0&',
    phone: '+923058832970',
    email: 'Example @gmail.com'
  },
   {
    id: '4',
    name: 'Ritika',
    position: 'DataBase',
    bio: '',
    image: 'https://cdn.discordapp.com/attachments/1287673374423646230/1417553021658861670/33uv0r2h.gif?ex=68cae6a1&is=68c99521&hm=4771e62a127bbb6eb125b2667bef28f74a5a54046f109d849a05993cf004abb0&',
    phone: '+923073878213',
    email: 'Example @gmail.com'
  }
];

export const testimonials = [
  // {
  //   id: '1',
  //   name: 'Talha Sheikh',
  //   text: 'I would like to involve national banks, such as HBL, to have an official presence in order to assist customers in case of any issues or fraudulent activities. This would help ensure proper record-keeping and support for customers facing such situations..',
  //   rating: 5,
  //   image: 'https://images.pexels.com/photos/1181424/pexels-photo-1181424.jpeg?auto=compress&cs=tinysrgb&w=300'
  // },
  // {
  //   id: '2',
  //   name: 'Robert Thompson',
  //   text: 'Outstanding service! They understood exactly what we were looking for and found us the perfect investment property with great potential.',
  //   rating: 5,
  //   image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=300'
  // },
  // {
  //   id: '3',
  //   name: 'Lisa Chen',
  //   text: 'Professional, knowledgeable, and always available when we needed them. Highly recommend for anyone looking to buy or sell property.',
  //   rating: 5,
  //   image: 'https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=300'
  // }
];