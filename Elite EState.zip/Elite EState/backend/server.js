const express = require("express");
const mysql = require("mysql2/promise");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
const PORT = 5000;
const JWT_SECRET = "your_secret_key"; // move to .env in production

app.use(cors());
app.use(express.json());

// ================== MYSQL CONNECTION ==================
const pool = mysql.createPool({
  host: "localhost",
  user: "root",     
  password: "12345",     
  database: "realestate_auth",
});

// ================== AUTH MIDDLEWARE ==================
const authenticate = async (req, res, next) => {
  const authHeader = req.headers["authorization"];
  if (!authHeader) return res.status(401).json({ message: "No token provided" });

  const token = authHeader.split(" ")[1]; // Bearer token
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded; // { id, role }
    next();
  } catch (err) {
    return res.status(403).json({ message: "Invalid or expired token" });
  }
};

// ================== AUTH ROUTES ==================

// ---------- SIGN UP ----------
app.post("/api/signup", async (req, res) => {
  try {
    const { name, email, phone, password, role, cnicFront, cnicBack } = req.body;
    const [rows] = await pool.query("SELECT * FROM users WHERE email = ?", [email]);
    if (rows.length > 0) {
      return res.status(400).json({ message: "Email already registered" });
    }

    if (!name || !email || !password || !role) {
      return res.status(400).json({ message: "All required fields must be filled" });
    }

    if (role === "seller") {
      if (!cnicFront || !cnicBack) {
        return res.status(400).json({ 
          message: "CNIC front and back photos are required for sellers" 
        });
      }
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    if (role === "seller") {
      await pool.query(
        "INSERT INTO users (name, email, phone, password, role, cnic_front_url, cnic_back_url, verification_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [name, email, phone, hashedPassword, role, cnicFront, cnicBack, "pending"]
      );
    } else {
      await pool.query(
        "INSERT INTO users (name, email, phone, password, role, verification_status) VALUES (?, ?, ?, ?, ?, ?)",
        [name, email, phone, hashedPassword, role, 'approved']
      );
    }

    res.json({ 
      message: role === "seller" 
        ? "Seller account created successfully. CNIC verification is pending." 
        : "User registered successfully" 
    });

  } catch (error) {
    console.error("Signup error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// ---------- SIGN IN ----------
app.post("/api/signin", async (req, res) => {
  try {
    const { email, password } = req.body;

    const [rows] = await pool.query("SELECT * FROM users WHERE email = ?", [email]);
    if (rows.length === 0) {
      return res.status(400).json({ message: "Invalid email or password" });
    }

    const user = rows[0];
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid email or password" });
    }

    const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: "1d" });

    res.json({
      message: "Sign in successful",
      token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
});

// ================== LISTINGS ROUTES ==================

// ---------- CREATE LISTING (SELLER ONLY) ----------
app.post("/api/listings", authenticate, async (req, res) => {
  try {
    const { 
      title, 
      description, 
      price, 
      property_type, 
      bedrooms, 
      bathrooms, 
      area, 
      location, 
      address, 
      image_url,
      featured 
    } = req.body;

    if (req.user.role !== "seller") {
      return res.status(403).json({ message: "Only sellers can create listings" });
    }

    // Validate required fields
    if (!title || !price || !property_type) {
      return res.status(400).json({ message: "Title, price, and property type are required" });
    }

    const [result] = await pool.query(
      `INSERT INTO listings 
       (seller_id, title, description, price, property_type, bedrooms, bathrooms, area, location, address, image_url, featured) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [req.user.id, title, description, price, property_type, bedrooms || 0, bathrooms || 0, area || null, location, address, image_url, featured || false]
    );

    res.json({
      message: "Listing created successfully",
      listing: {
        id: result.insertId,
        seller_id: req.user.id,
        title,
        description,
        price,
        property_type,
        bedrooms: bedrooms || 0,
        bathrooms: bathrooms || 0,
        area,
        location,
        address,
        image_url,
        featured: featured || false,
        status: 'active'
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});


app.get("/api/verification-status/:userId", async (req, res) => {
  console.log('hii')
  try {
    const { userId } = req.params;
    
    // Ensure user can only check their own status (or admin can check anyone's)
    if (req.user.id !== parseInt(userId) && req.user.role !== 'admin') {
      return res.status(403).json({ 
        message: "You can only check your own verification status" 
      });
    }

    const [rows] = await pool.query(
      "SELECT verification_status, role FROM users WHERE id = ?", 
      [userId]
    );

    if (rows.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    const user = rows[0];

    // Only sellers have verification status
    if (user.role !== 'seller') {
      return res.status(400).json({ 
        message: "Verification status is only applicable for sellers" 
      });
    }

    res.json({ 
      verification_status: user.verification_status || 'pending',
      message: `Verification status: ${user.verification_status || 'pending'}`
    });

  } catch (error) {
    console.error("Verification status check error:", error);
    res.status(500).json({ message: "Server error" });
  }
});


// ---------- GET MY LISTINGS (SELLER ONLY) ----------

app.get("/api/my-listings", authenticate, async (req, res) => {
  try {
    if (req.user.role !== "seller") {
      return res.status(403).json({ message: "Only sellers can access this endpoint" });
    }

    const [listings] = await pool.query(
      `SELECT l.*, u.name AS seller_name
       FROM listings l
       JOIN users u ON l.seller_id = u.id
       WHERE l.seller_id = ?
       ORDER BY l.created_at DESC`,
      [req.user.id]
    );

    const [userStatus] = await pool.query(
      `SELECT verification_status
       FROM users
       WHERE id = ?`,
      [req.user.id]
    );

    if (userStatus.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json({
      listings: listings,
      verification_status: userStatus[0].verification_status
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});


// ---------- GET ALL LISTINGS (PUBLIC) ----------
app.get("/api/listings", async (req, res) => {
  try {
    const { 
      property_type, 
      min_price, 
      max_price, 
      bedrooms, 
      bathrooms, 
      location, 
      status = 'active',
      sort = 'created_at',
      order = 'DESC',
      limit = 50,
      offset = 0 
    } = req.query;

    let query = `
      SELECT l.*, u.name AS seller_name 
      FROM listings l 
      JOIN users u ON l.seller_id = u.id 
      WHERE l.status = ?
    `;
    const params = [status];

    // Add filters
    if (property_type) {
      query += " AND l.property_type = ?";
      params.push(property_type);
    }
    if (min_price) {
      query += " AND l.price >= ?";
      params.push(parseFloat(min_price));
    }
    if (max_price) {
      query += " AND l.price <= ?";
      params.push(parseFloat(max_price));
    }
    if (bedrooms) {
      query += " AND l.bedrooms >= ?";
      params.push(parseInt(bedrooms));
    }
    if (bathrooms) {
      query += " AND l.bathrooms >= ?";
      params.push(parseInt(bathrooms));
    }
    if (location) {
      query += " AND l.location LIKE ?";
      params.push(`%${location}%`);
    }

    // Add sorting
    const validSortFields = ['price', 'created_at', 'title', 'bedrooms', 'bathrooms'];
    const sortField = validSortFields.includes(sort) ? sort : 'created_at';
    const sortOrder = order.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';
    
    query += ` ORDER BY l.${sortField} ${sortOrder}`;
    
    // Add pagination
    query += " LIMIT ? OFFSET ?";
    params.push(parseInt(limit), parseInt(offset));

    const [results] = await pool.query(query, params);
    res.json(results);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

// ---------- GET SINGLE LISTING ----------
app.get("/api/listings/:id", async (req, res) => {
  try {
    const [results] = await pool.query(
      `SELECT l.*, u.name AS seller_name, u.email AS seller_email, u.phone AS seller_phone 
       FROM listings l 
       JOIN users u ON l.seller_id = u.id 
       WHERE l.id = ?`,
      [req.params.id]
    );

    if (results.length === 0) {
      return res.status(404).json({ message: "Listing not found" });
    }

    res.json(results[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

// ---------- UPDATE LISTING (SELLER ONLY - OWN LISTINGS) ----------
app.put("/api/listings/:id", authenticate, async (req, res) => {
  try {
    if (req.user.role !== "seller") {
      return res.status(403).json({ message: "Only sellers can update listings" });
    }

    // Check if listing belongs to the user
    const [existing] = await pool.query(
      "SELECT * FROM listings WHERE id = ? AND seller_id = ?",
      [req.params.id, req.user.id]
    );

    if (existing.length === 0) {
      return res.status(404).json({ message: "Listing not found or access denied" });
    }

    const { 
      title, 
      description, 
      price, 
      property_type, 
      bedrooms, 
      bathrooms, 
      area, 
      location, 
      address, 
      image_url,
      featured,
      status 
    } = req.body;

    await pool.query(
      `UPDATE listings 
       SET title = COALESCE(?, title),
           description = COALESCE(?, description),
           price = COALESCE(?, price),
           property_type = COALESCE(?, property_type),
           bedrooms = COALESCE(?, bedrooms),
           bathrooms = COALESCE(?, bathrooms),
           area = COALESCE(?, area),
           location = COALESCE(?, location),
           address = COALESCE(?, address),
           image_url = COALESCE(?, image_url),
           featured = COALESCE(?, featured),
           status = COALESCE(?, status),
           updated_at = CURRENT_TIMESTAMP
       WHERE id = ? AND seller_id = ?`,
      [title, description, price, property_type, bedrooms, bathrooms, area, location, address, image_url, featured, status, req.params.id, req.user.id]
    );

    res.json({ message: "Listing updated successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

// ---------- DELETE LISTING (SELLER ONLY - OWN LISTINGS) ----------
app.delete("/api/listings/:id", authenticate, async (req, res) => {
  try {
    if (req.user.role !== "seller" && req.user.role !== "admin") {
      return res.status(403).json({ message: "Only admin/sellers can delete listings" });
    }

    const [result] = await pool.query(
      "DELETE FROM listings WHERE id = ? AND seller_id = ?",
      [req.params.id, req.user.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Listing not found or access denied" });
    }

    res.json({ message: "Listing deleted successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});


// ================== Admin ==================
app.get('/api/dashboard/stats', authenticate, async (req, res) => {
  try {
    if (req.user.role !== "admin") {
      return res.status(403).json({ message: "Only admin can access this endpoint" });
    }
   
    const [totalUsers] = await pool.query(
      "SELECT COUNT(*) AS total FROM users"
    );

    // Query Pending Verifications
    const [pendingVerifications] = await pool.query(
      "SELECT COUNT(*) AS total FROM users WHERE verification_status = 'pending'"
    );

    // Query Total Listings
    const [totalListings] = await pool.query(
      "SELECT COUNT(*) AS total FROM listings"
    );

    res.json({
      success: true,
      data: {
        totalUsers: totalUsers[0].total,
        pendingVerifications: pendingVerifications[0].total,
        totalListings: totalListings[0].total
      }
    });
  } catch (err) {
    console.error("Dashboard Error:", err);
    res.status(500).json({ success: false, message: "Server Error" });
  }
});

app.post("/api/dashboard/verification", authenticate, async (req, res) => {
  const { action, userId } = req.body;
  try {
    if (req.user.role !== "admin") {
      return res.status(403).json({ message: "Only admin can access this endpoint" });
    }
    // Fetch Pending Users
    if (action === "fetch") {
      const [rows] = await pool.query(
        "SELECT id, name, email, phone AS number, created_at, cnic_front_url, cnic_back_url FROM users WHERE verification_status = 'pending'"
      );
      return res.json({ success: true, data: rows });
    }

    // Approve
    if (action === "approve") {
      await pool.query(
        "UPDATE users SET verification_status = 'approved' WHERE id = ?",
        [userId]
      );
      return res.json({
        success: true,
        message: "User approved successfully",
      });
    }

    // Reject
    if (action === "rejected") {
      await pool.query(
        "UPDATE users SET verification_status = 'rejected' WHERE id = ?",
        [userId]
      );
      return res.json({
        success: true,
        message: "User rejected successfully",
      });
    }

    return res.json({ success: false, message: "Invalid action" });

  } catch (err) {
    console.error("Verification Error:", err);
    res.status(500).json({ success: false, message: "Server Error" });
  }
});


app.get("/api/dashboard/users", authenticate, async (req, res) => {
      const [totalUsers] = await pool.query(
      "SELECT id, name, email, phone, role, created_at, LEFT(cnic_front_url, 256) AS cnic_front_url, LEFT(cnic_back_url, 256) AS cnic_back_url, verification_status FROM users ORDER BY role"
    );
    res.json(totalUsers);
});

app.post("/api/dashboard/users", authenticate, async (req, res) => {
  const { action, userId, newStatus } = req.body;

  // -------------------------------
  // DELETE USER
  // -------------------------------
  if (action === "delete") {
    pool.query(`DELETE FROM users WHERE id = ?`, [userId], (err) => {
      if (err) return res.status(500).json({ error: err });
      return res.json({ success: true, message: "User deleted" });
    });
    return;
  }

  // -------------------------------
  // UPDATE VERIFICATION STATUS
  // -------------------------------
  if (action === "status") {
    pool.query(
      `UPDATE users SET verification_status = ? WHERE id = ?`,
      [newStatus, userId],
      (err) => {
        if (err) return res.status(500).json({ error: err });
        return res.json({
          success: true,
          message: "Status updated",
          newStatus,
        });
      }
    );
    return;
  }

  return res.status(400).json({ error: "Invalid action" });
});


app.get("/api/dashboard/listing", async (req, res) => {
  try {
    const { 
      status = 'active',
      sort = 'created_at',
      order = 'DESC',
      limit = 50,
      offset = 0 
    } = req.query;

    let query = `
      SELECT l.*, u.name AS seller_name 
      FROM listings l 
      JOIN users u ON l.seller_id = u.id 
    `;
    const params = [status];

    params.push(parseInt(limit), parseInt(offset));

    const [results] = await pool.query(query, params);
    res.json(results);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

// ================== START ==================
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});